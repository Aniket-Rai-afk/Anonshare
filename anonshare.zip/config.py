# AnonShare – Configuration

RELAY_URL = "ws://relay.magic-wormhole.io:4000/v1"
APP_ID    = "anonshare.secure.v1"

# Tor
TOR_SOCKS_HOST   = "127.0.0.1"
TOR_SOCKS_PORT   = 9050
TOR_CONTROL_PORT = 9051
TOR_CHECK_URL    = "https://check.torproject.org/api/ip"
TOR_CHECK_TIMEOUT = 15

# Session
DEFAULT_TIMEOUT      = 3600
MIN_PASSPHRASE_LENGTH = 12

# Crypto
PBKDF2_ITERATIONS = 100_000
KEY_LENGTH        = 32          # bytes (256 bits)
ENABLE_PADDING    = True
PADDING_BLOCK_SIZE = 65536      # 64 KB

# I/O
CHUNK_SIZE = 16 * 1024          # 16 KB streaming chunk

# Timing-analysis resistance
TIMING_DELAY_MIN = 0.5          # seconds
TIMING_DELAY_MAX = 3.0
